interface Produkt {
  ean: string;
  naz: string;
  kat: string;
  sek: string;
  re: string;
  pol: string;
  il: number;
}
 


let produkty: Produkt[] = [
  { ean: "1", naz: "żatówka", kat: "światło", sek: "a", re: "4", pol: "7", il: 50 },
  { ean: "2", naz: "kabel HDMI", kat: "kable", sek: "c", re: "1", pol: "3", il: 45 },
];


const pole = (id: string) => document.getElementById(id) as HTMLInputElement;

const tabela = document.getElementById("tabela") as HTMLTableSectionElement;



function pokaz(): void {
  tabela.innerHTML = "";
  for (const p of produkty) {
    tabela.innerHTML += `<tr>
      <td>${p.ean}</td><td>${p.naz}</td><td>${p.kat}</td>
      <td>${p.sek}-${p.re}-${p.pol}</td><td>${p.il}</td>
      <td>

        <button data-ean="${p.ean}" data-akcja="przyjecie">przyjmij</button>
        <button data-ean="${p.ean}" data-akcja="wydanie">wydaj</button>
        <button data-ean="${p.ean}" data-akcja="edytuj">edytuj</button>
      </td></tr>`;
  }
}

function dodajProdukt(): void {
  const ean = pole("ean").value.trim();
  const naz = pole("naz").value.trim();
  if (ean === "" || naz === "") {
    alert("wpisz EAN i nazwe");
    return;


  }


  if (produkty.some((p) => p.ean === ean)) {
    alert("taki EAN juz istnieje");
    return;
  }


  produkty.push({
    ean: ean, naz: naz, kat: pole("kat").value,
    sek: pole("sek").value, re: pole("re").value,
    pol: pole("po").value, il: 0,
  });
  for (const id of ["ean", "naz", "kat", "sek", "re", "po"]) pole(id).value = "";
  pokaz();

}



function edytujProdukt(p: Produkt): void {
  p.naz = prompt("Nazwa:", p.naz) ?? p.naz;
  p.kat = prompt("Kategoria:", p.kat) ?? p.kat;
  pokaz();
}



function zmienStan(p: Produkt, rodzaj: string): void {
  const ilosc = Number(prompt("Ilosc (" + rodzaj + "):"));
  if (!Number.isInteger(ilosc) || ilosc <= 0) {
    alert("zla ilosc");
    return;
  }

  if (rodzaj === "wydanie" && ilosc > p.il) {
    alert("na stanie jest tylko " + p.il);
    return;
  }


  p.il += rodzaj === "przyjecie" ? ilosc : -ilosc;
  pokaz();
}
tabela.onclick = (e: MouseEvent) => {
  const przycisk = e.target as HTMLButtonElement;
  const p = produkty.find((x) => x.ean === przycisk.dataset.ean);
  if (!p) return;
  if (przycisk.dataset.akcja === "edytuj") edytujProdukt(p);
  else zmienStan(p, przycisk.dataset.akcja ?? "");
};



pole("dodaj").onclick = dodajProdukt;
pokaz();
